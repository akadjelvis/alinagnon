/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bj.uac.ifri.lc2016.akadjelvis.pfe.alinagnon;

/**
 *
 * @author akadjelvis
 */
public class RetournerClass {

    private String s;
    private boolean b;

    public void setS(String s) {
        this.s = s;
    }

    public void setB(boolean b) {
        this.b = b;
    }

    public String getS() {
        return s;
    }

    public boolean getB() {
        return b;
    }
}
